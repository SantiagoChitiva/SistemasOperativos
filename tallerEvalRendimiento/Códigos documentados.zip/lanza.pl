#!/usr/bin/perl
#**************************************************************
#                       Pontificia Universidad Javeriana
#     Autor: S. Chitiva
#     Fecha: Mayo 2024
#     Materia: Sistemas Operativos
#     Tema: Taller de Evaluación de Rendimiento
#     Fichero: script automatización ejecución por lotes
#***************************************************************

# Obtener y almacenar el directorio actual de trabajo
$Path = pwd;
chomp($Path);  # Eliminar el salto de línea del final de la cadena

# Definir arreglos con los nombres de los ejecutables, tamaños de matrices y números de hilos
@Nombre_Ejecutable = ("clasico", "transpuesta");  # Nombres de los programas ejecutables
@Size_Matriz = ("200", "300");  # Tamaños de las matrices
@Num_Hilos = (1, 2);  # Cantidades de hilos a usar
$Repeticiones = 30;  # Número de veces que se repetirá cada ejecución (30 debido a la ley de grandes números)

# Bucle anidado para recorrer cada combinación de ejecutable, tamaño de matriz y número de hilos
foreach $nombre (@Nombre_Ejecutable) {
    foreach $size (@Size_Matriz) {
        foreach $hilo (@Num_Hilos) {
            # Crear el nombre del archivo de salida en el que se guardarán los resultados
            $file = "$Path/$nombre-".$size."-Hilos-".$hilo.".dat";

            # Repetir la ejecución del programa el número especificado de veces
            for ($i = 0; $i < $Repeticiones; $i++) {
                # Ejecutar el programa con los parámetros actuales y redirigir la salida al archivo
                system("$Path/$nombre $size $hilo >> $file");
            }
            close($file);  # Cerrar el archivo de salida (opcional en Perl, ya que se cierra automáticamente)
        }
    }
}
