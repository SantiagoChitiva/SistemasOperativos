/**************************************************************
    Pontificia Universidad Javeriana
  Autor: S. Chitiva
  Fecha: Mayo 2024
  Materia: Sistemas Operativos
  Tema: Taller de Evaluacion de Rendimiento
  Fichero: fuente de multiplicacion de matrices NxN por hilos.
  Objetivo: Evaluar el tiempo de ejecucion del 
          algoritmo clasico de multiplicacion de matrices.
        Se implementa con la Biblioteca POSIX Pthreads
****************************************************************/

#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

// Tamaño de los datos 
#define DATA_SIZE (1024*1024*64*3) 

// Definición de un mutex para proteger secciones críticas
pthread_mutex_t MM_mutex;

// Definición de un bloque de memoria estática para las matrices
static double MEM_CHUNK[DATA_SIZE];
double *mA, *mB, *mC;

// Estructura para pasar parámetros a los hilos
struct parametros {
  int nH;  // Número de hilos
  int idH; // Identificador del hilo
  int N;   // Tamaño de la matriz
};

// Variables para medir el tiempo de ejecución
struct timeval start, stop;

// Función para llenar las matrices con valores iniciales
void llenar_matriz(int SZ) { 
  srand48(time(NULL));
  for (int i = 0; i < SZ * SZ; i++) {
    mA[i] = 1.1 * i; // Inicializar mA con valores
    mB[i] = 2.2 * i; // Inicializar mB con valores
    mC[i] = 0;       // Inicializar mC con ceros
  }	
}

// Función para imprimir una matriz, cuando su tamaño es menor a 12
void print_matrix(int sz, double *matriz) {
  if (sz < 12) {
    for (int i = 0; i < sz * sz; i++) {
      if (i % sz == 0) printf("\n");
      printf(" %.3f ", matriz[i]);
    }
    printf("\n>-------------------->\n");
  }
}

// Función para inicializar la medición del tiempo
void inicial_tiempo() {
  gettimeofday(&start, NULL);
}

// Función para finalizar la medición del tiempo y mostrar el tiempo transcurrido
void final_tiempo() {
  gettimeofday(&stop, NULL);
  stop.tv_sec -= start.tv_sec;
  printf("\n:-> %9.0f µs\n", (double) (stop.tv_sec * 1000000 + stop.tv_usec));
}

// Función que ejecutan los hilos para realizar la multiplicación de matrices
void *mult_thread(void *variables) {
  struct parametros *data = (struct parametros *)variables;

  int idH = data->idH;
  int nH  = data->nH;
  int N   = data->N;
  int ini = (N / nH) * idH;
  int fin = (N / nH) * (idH + 1);

    for (int i = ini; i < fin; i++) {
        for (int j = 0; j < N; j++) {
      double *pA, *pB, sumaTemp = 0.0;
      pA = mA + (i * N); 
      pB = mB + (j * N);
            for (int k = 0; k < N; k++, pA++, pB++) {
        sumaTemp += (*pA * *pB);
      }
      mC[i * N + j] = sumaTemp;
    }
  }

  pthread_mutex_lock(&MM_mutex);
  pthread_mutex_unlock(&MM_mutex);
  pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
  if (argc < 2) {
    printf("Ingreso de argumentos \n $./ejecutable tamMatriz numHilos\n");
    return -1;	
  }
    int SZ = atoi(argv[1]);    // Tamaño de la matriz
    int n_threads = atoi(argv[2]); // Número de hilos

    pthread_t p[n_threads];    // Arreglo para almacenar identificadores de hilos
    pthread_attr_t atrMM;      // Atributos para los hilos

  mA = MEM_CHUNK;
  mB = mA + SZ * SZ;
  mC = mB + SZ * SZ;

  llenar_matriz(SZ);         // Llenar las matrices con valores iniciales
  print_matrix(SZ, mA);      // Imprimir la matriz A
  print_matrix(SZ, mB);      // Imprimir la matriz B 

  inicial_tiempo();          // Iniciar la medición del tiempo
  pthread_mutex_init(&MM_mutex, NULL);
  pthread_attr_init(&atrMM);
  pthread_attr_setdetachstate(&atrMM, PTHREAD_CREATE_JOINABLE);

    for (int j = 0; j < n_threads; j++) {
    struct parametros *datos = (struct parametros *) malloc(sizeof(struct parametros)); 
    datos->idH = j;
    datos->nH  = n_threads;
    datos->N   = SZ;
        pthread_create(&p[j], &atrMM, mult_thread, (void *)datos);
  }

    for (int j = 0; j < n_threads; j++)
        pthread_join(p[j], NULL);
  final_tiempo();            // Finalizar la medición del tiempo

  print_matrix(SZ, mC);      // Imprimir la matriz C 

  pthread_attr_destroy(&atrMM);
  pthread_mutex_destroy(&MM_mutex);
  pthread_exit(NULL);
}
